
    public class Main {
    public static void main(String[] args) {
        long toplam = 0;

        // 1 ile 20 arasındaki çift sayılar (2, 4, 6, ..., 20)
        for (int i = 2; i <= 20; i += 2) {
            long kup = (long) i * i * i;
            toplam += kup;
            System.out.println(i + " sayısının küpü: " + kup);
        }

        System.out.println("----------------------------------------");
        System.out.println("Çift sayıların küpleri toplamı: " + toplam);
    }
}
